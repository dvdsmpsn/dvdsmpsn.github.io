Deere Touch - a touchscreen-friendly copy of Mixxx's Deere skin
================================================================

Based on the Deere skin shipped with Mixxx 2.5.6. Tested with the Mixxx
2.5.6 Flatpak on a Raspberry Pi 5 with a 1920x1200 touchscreen at
Mixxx scale factor 150%.

Changes from Deere:
  - A bar of big buttons above the track list:
      LOAD DECK 1 | LIBRARY [maximise/minimise icon] | LOAD DECK 2
    Tap a track, then a LOAD button. LIBRARY (or its icon) toggles the
    maximised library; it turns green and the icon switches to "minimise"
    while it's on. Icons: Material Design fullscreen / fullscreen exit
    (Apache 2.0).
  - The search box, sidebar and cover art only show in the big library;
    in the normal view the track list uses the full width.
  - Bigger buttons on decks 1 and 2 (x1.5); the rest keeps Deere's sizes.
  - The vinyl control section (VINYL / REL / CUE) is always visible.
  - MIXER and EFFECTS are hidden every time Mixxx starts (tap to show).
  - Template paths changed from skins:Deere/ to skin: so the copy loads
    its own files from the user skins folder.

Optional: closing the big library after a LOAD button needs a small
controller script; see Step 15 of the blog post
(djm-250mk2-mixxx-dvs-raspberry-pi.md).

Install (Flatpak):
  mkdir -p ~/.var/app/org.mixxx.Mixxx/.mixxx/skins
  unzip DeereTouch-mixxx-skin.zip -d /tmp/deere-touch
  cp -r /tmp/deere-touch/DeereTouch ~/.var/app/org.mixxx.Mixxx/.mixxx/skins/
Install (non-Flatpak): copy DeereTouch into ~/.mixxx/skins/ instead.
Then choose "Deere Touch" in Preferences > Interface > Skin.

Licence: Deere is licensed under CC BY-SA 3.0 (see the header of
style.qss). This modified copy is shared under the same licence.
